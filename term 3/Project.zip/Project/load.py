def load(data, file_path):
    data.to_csv(file_path,index = False)