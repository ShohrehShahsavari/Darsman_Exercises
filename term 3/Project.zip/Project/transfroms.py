import plotly.express as px
from sklearn.preprocessing import KBinsDiscretizer
from sklearn.preprocessing import LabelEncoder
import pandas as pd

#* حذف رکورد های کاملا خالی
def drop_record_all_nan(data):
    return data.dropna(how="all", axis=0)





#* جایگزین کردن داده غیر عددی با مقدار NAN برای همه ستونهای عددی 
def fill_noisy_data_on_numeric_col(data):
    data['Weight'] = pd.to_numeric(data['Weight'], errors='coerce')
    data['PurchaseAmount'] = pd.to_numeric(data['PurchaseAmount'], errors='coerce')
    data['Quantity'] = pd.to_numeric(data['Quantity'], errors='coerce')
    return data



#* پر کردن فیلدهای خالی برای تمام ویژگیها
def fill_nan_fields(data):
    data.fillna(value={
        'CustomerName': data.CustomerName.mode()[0],
        'PurchaseDate': data.PurchaseDate.mode()[0],
        'Product': data.Product.mode()[0],
        'Quantity': data.Quantity.mean(),
        'PurchaseAmount': data.PurchaseAmount.mean(),
        'Color': data.Color.mode()[0],
        'IsAvailable': data.IsAvailable.mode()[0],
        'Weight': data.Weight.mean()
    }, inplace=True)
    return data
 

# تغییر نوع داده ها مثلا تنظیم تعداد اعشار داده های اعشاری 
def change_data_type(data):
    data['Weight'] = round(data["Weight"], 0)
    data = data.astype({'Quantity': 'int'})
    return data





# نمایش وزنهای پرت
def check_weight_outlier(data, columns):
    fig = px.box(data, y=columns)
    fig.show()

# حذف وزنهای پرت
def remove_weight_outlier(data, min_w, max_w):
    return  data[(data['Weight'] >= min_w) & (data["Weight"] <= max_w)]


#* گسسته سازی داده ها
def k_bins_discretizer(data, columns):
    dis = KBinsDiscretizer(n_bins=5, encode='ordinal', strategy='uniform')
    for col in columns:
        data[col] = dis.fit_transform(data[[col]])
        data = data.astype({col: 'int'})
    return data






### رمزگزاری داده ها 
# # one_hot_encoder
def one_hot_encoder(data, columns):
    return pd.get_dummies(data, columns=columns)


### رمزگزاری داده ها 
# # label_encoder
def label_encoder(data, columns):
    le = LabelEncoder()
    for col in columns:
        data[col] = le.fit_transform(data[col])
    return data




# # حذف کردن ستون
def drop_columns(data, columns):
    for col in columns:
        data.drop(col, axis=1, inplace=True)
    return data




# نرمال سازی
from sklearn.preprocessing import MinMaxScaler
def min_max_scaler(data, columns):
    scaler = MinMaxScaler()
    data = scaler.fit_transform(data)
    data = pd.DataFrame(data)
    data.columns = columns
    return data



# استاندار سازی
from sklearn.preprocessing import StandardScaler
def standard_scaler(data, columns):
    scaler = StandardScaler()
    data = scaler.fit_transform(data)
    data = pd.DataFrame(data)
    data.columns = columns
    return data