from extracctions import *
from transfroms import *
from load import *

# ---------------------------------------------------------------------
# نمایش داده
def display_data(data):
    print(100 * '*')
    print(data)
    print(100 * '-')

# ---------------------------------------------------------------------
# خواندن فایل
data = read_csv_file('data\orders.csv')


# # ---------------------------------------------------------------------
# حذف رکورد های کاملا خالی
data = drop_record_all_nan(data)

# # ---------------------------------------------------------------------
# #جایگزین کردن داده غیر عددی با مقدار خالی برای همه ستونهای عددی 
data = fill_noisy_data_on_numeric_col(data)


# # ---------------------------------------------------------------------
# # پر کردن فیلدهای خالی برای تمام ویژگیها
data = fill_nan_fields(data)

# # ---------------------------------------------------------------------
# # تغییر نوع داده ها مثلا تنظیم تعداد اعشار داده های اعشاری 
data = change_data_type(data)


# # ---------------------------------------------------------------------
# # نمایش وزنهای پرت
# check_weight_outlier(data,columns=['Weight'])

# # ---------------------------------------------------------------------
# # حذف وزنهای پرت
data=remove_weight_outlier(data, min_w=40, max_w=120)


# # ---------------------------------------------------------------------
# # گسسته سازی ستون وزن
data = k_bins_discretizer(data, columns=['Weight'])



# # ---------------------------------------------------------------------
# # one_hot_encoder for IsAvailable
data = one_hot_encoder(data, columns=['IsAvailable'])

# # ---------------------------------------------------------------------
# # label_encoder for Product , Color
data = label_encoder(data, columns=['Product', 'Color'])

# # ---------------------------------------------------------------------
#  # حذف کردن ستونهای نام مشتری و تاریخ خرید 
drop_columns(data, columns=["CustomerName","PurchaseDate"])

# # ---------------------------------------------------------------------
# # نرمال سازی
data = min_max_scaler(data, ['Product',  'Quantity',  'PurchaseAmount', 'Color',  'Weight',  'IsAvailable_No',  'IsAvailable_Yes'])

# # ---------------------------------------------------------------------
# # استاندار سازی
# data = standard_scaler(data, ['Product',  'Quantity',  'PurchaseAmount', 'Color',  'Weight',  'IsAvailable_No',  'IsAvailable_Yes'])

# # ---------------------------------------------------------------------
display_data(data)

# # ---------------------------------------------------------------------
# # ذخیره داده
load(data,"./data/target.csv")